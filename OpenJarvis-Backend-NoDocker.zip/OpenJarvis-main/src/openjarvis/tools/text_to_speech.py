"""Text-to-speech tool — synthesize text to audio via configurable TTS backend."""

from __future__ import annotations

import re
import tempfile
import uuid
from pathlib import Path
from typing import Any

from openjarvis.core.registry import ToolRegistry, TTSRegistry
from openjarvis.core.types import ToolResult
from openjarvis.tools._stubs import BaseTool, ToolSpec


@ToolRegistry.register("text_to_speech")
class TextToSpeechTool(BaseTool):
    """Synthesize text into spoken audio using a TTS backend."""

    tool_id = "text_to_speech"
    is_local = False

    @property
    def spec(self) -> ToolSpec:
        return ToolSpec(
            name="text_to_speech",
            description=(
                "Convert text to spoken audio. Returns the file path to the "
                "generated audio file."
            ),
            parameters={
                "type": "object",
                "properties": {
                    "text": {
                        "type": "string",
                        "description": "The text to synthesize into speech.",
                    },
                    "voice_id": {
                        "type": "string",
                        "description": "Voice identifier for the TTS backend.",
                    },
                    "backend": {
                        "type": "string",
                        "description": (
                            "TTS backend (cartesia, elevenlabs, kokoro, openai_tts)."
                        ),
                    },
                    "output_dir": {
                        "type": "string",
                        "description": "Directory to save the audio file.",
                    },
                },
                "required": ["text"],
            },
            category="audio",
            timeout_seconds=120.0,
        )

    def execute(self, **params: Any) -> ToolResult:
        # Ensure TTS backends are registered
        import openjarvis.speech  # noqa: F401

        text = params.get("text", "")
        voice_id = params.get("voice_id", "")
        backend_key = params.get("backend", "")

        # Fall back to the configured speech voice so the agent-facing tool
        # speaks in the same voice as `jarvis chat --voice` instead of the
        # backend default. Explicit params always win.
        if not voice_id or not backend_key:
            try:
                from openjarvis.core.config import load_config

                speech = getattr(load_config(), "speech", None)
                if not backend_key:
                    backend_key = getattr(speech, "tts_backend", "") or ""
                if not voice_id and backend_key == getattr(speech, "tts_backend", None):
                    voice_id = getattr(speech, "voice_id", "") or ""
            except Exception:
                pass
        backend_key = backend_key or "cartesia"
        _ALIASES = {"openai": "openai_tts"}
        backend_key = _ALIASES.get(backend_key, backend_key)
        output_dir = params.get("output_dir", "")
        # Read speed without a falsy default so "the caller did not set speed"
        # stays distinct from a real value. Note 0 is a legitimate value and
        # must not be discarded here.
        raw_speed = params.get("speed")
        speed = float(raw_speed) if raw_speed not in (None, "") else None

        if not text:
            return ToolResult(
                tool_name="text_to_speech",
                content="No text provided.",
                success=False,
            )

        if not TTSRegistry.contains(backend_key):
            return ToolResult(
                tool_name="text_to_speech",
                content=f"TTS backend '{backend_key}' not available.",
                success=False,
            )

        backend_cls = TTSRegistry.get(backend_key)
        backend = backend_cls()

        # Only forward parameters the caller (or config) actually set. Passing
        # voice_id="" or speed=1.0 unconditionally overrides each backend's own
        # default value: kokoro's synthesize() defaults voice_id to "af_heart",
        # and an empty string overrides it so the local backend is asked for a
        # voice named "" and 404s while paid backends happen to tolerate it.
        synth_kwargs: dict[str, Any] = {}
        if voice_id:
            synth_kwargs["voice_id"] = voice_id
        if speed is not None:
            synth_kwargs["speed"] = speed
        result = backend.synthesize(text, **synth_kwargs)

        # Save to file
        if output_dir:
            out_dir = Path(output_dir)
        else:
            out_dir = Path(tempfile.mkdtemp(prefix="jarvis-tts-"))

        out_dir.mkdir(parents=True, exist_ok=True)
        ext = result.format or "mp3"
        # Name each file uniquely so several lines saved to one output_dir do
        # not overwrite each other. A random token (not a timestamp) guarantees
        # uniqueness even for back-to-back calls with identical text and voice.
        slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:40] or "line"
        voice_tag = (result.voice_id or "")[:8] or backend_key
        audio_path = out_dir / f"{slug}-{voice_tag}-{uuid.uuid4().hex[:8]}.{ext}"
        result.save(audio_path)

        return ToolResult(
            tool_name="text_to_speech",
            content=str(audio_path),
            success=True,
            metadata={
                "audio_path": str(audio_path),
                "format": ext,
                "duration_seconds": result.duration_seconds,
                "voice_id": result.voice_id,
                "backend": backend_key,
            },
        )
