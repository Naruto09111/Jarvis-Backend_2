"""OmniRoute inference engine.

OmniRoute is a self-hosted AI gateway that exposes an OpenAI-compatible API
(``POST /v1/chat/completions`` with SSE streaming, ``GET /v1/models``, Bearer
auth).  Everything protocol-related is therefore inherited from
``_OpenAICompatibleEngine``; this module only adds:

* configuration through environment variables
  (``OMNIROUTE_HOST``, ``OMNIROUTE_API_KEY``, ``OMNIROUTE_MAX_RETRIES``),
* tolerance for a base URL pasted with its ``/v1`` suffix, and
* a small retry policy for transient gateway failures (HTTP 429/502/503/504
  and connection failures) applied **before** any response body is consumed,
  so a streamed answer is never replayed half-way.

Model IDs are passed to the gateway unchanged, so whatever IDs/combos your
OmniRoute instance exposes (see its dashboard or ``GET /v1/models``) can be
used with ``--model`` / ``OPENJARVIS_MODEL``.

No endpoint is hardcoded for production: the ``localhost:20128`` default is
only the address of a locally running OmniRoute.  A Render deployment must set
``OMNIROUTE_HOST`` to a publicly reachable HTTPS URL.
"""

from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import Callable

import httpx

from openjarvis.core.registry import EngineRegistry
from openjarvis.engine._openai_compat import _OpenAICompatibleEngine
from openjarvis.engine.openai_compat_engines import normalize_openai_base_url

logger = logging.getLogger(__name__)

_RETRY_STATUSES = frozenset({429, 502, 503, 504})
_DEFAULT_RETRIES = 2
_BACKOFF_BASE_S = 0.5
_MAX_DELAY_S = 5.0


def _retry_delay(response: httpx.Response | None, attempt: int) -> float:
    """Seconds to wait before retry ``attempt`` (0-based); honours Retry-After."""
    if response is not None:
        raw = response.headers.get("retry-after", "")
        try:
            return max(0.0, min(float(raw), _MAX_DELAY_S))
        except ValueError:
            pass
    return min(_BACKOFF_BASE_S * (2**attempt), _MAX_DELAY_S)


class _RetryTransport(httpx.BaseTransport):
    """Sync transport that retries transient failures before the body is read."""

    def __init__(
        self,
        inner: httpx.BaseTransport,
        retries: int,
        sleep: Callable[[float], None] = time.sleep,
    ) -> None:
        self._inner = inner
        self._retries = retries
        self._sleep = sleep

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        attempt = 0
        while True:
            try:
                response = self._inner.handle_request(request)
            except (httpx.ConnectError, httpx.ConnectTimeout):
                # The request never reached the gateway, so replaying is safe.
                if attempt >= self._retries:
                    raise
                self._sleep(_retry_delay(None, attempt))
                attempt += 1
                continue
            if response.status_code in _RETRY_STATUSES and attempt < self._retries:
                delay = _retry_delay(response, attempt)
                response.close()
                logger.warning(
                    "OmniRoute returned HTTP %s; retrying in %.1fs",
                    response.status_code,
                    delay,
                )
                self._sleep(delay)
                attempt += 1
                continue
            return response

    def close(self) -> None:
        self._inner.close()


class _AsyncRetryTransport(httpx.AsyncBaseTransport):
    """Async twin of :class:`_RetryTransport` (used by the streaming path)."""

    def __init__(
        self,
        inner: httpx.AsyncBaseTransport,
        retries: int,
        sleep: Callable[[float], object] = asyncio.sleep,
    ) -> None:
        self._inner = inner
        self._retries = retries
        self._sleep = sleep

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        attempt = 0
        while True:
            try:
                response = await self._inner.handle_async_request(request)
            except (httpx.ConnectError, httpx.ConnectTimeout):
                if attempt >= self._retries:
                    raise
                await self._sleep(_retry_delay(None, attempt))  # type: ignore[misc]
                attempt += 1
                continue
            if response.status_code in _RETRY_STATUSES and attempt < self._retries:
                delay = _retry_delay(response, attempt)
                await response.aclose()
                logger.warning(
                    "OmniRoute returned HTTP %s; retrying in %.1fs",
                    response.status_code,
                    delay,
                )
                await self._sleep(delay)  # type: ignore[misc]
                attempt += 1
                continue
            return response

    async def aclose(self) -> None:
        await self._inner.aclose()


def _env_retries() -> int:
    raw = os.environ.get("OMNIROUTE_MAX_RETRIES", "")
    try:
        return max(0, min(int(raw), 5)) if raw.strip() else _DEFAULT_RETRIES
    except ValueError:
        return _DEFAULT_RETRIES


@EngineRegistry.register("omniroute")
class OmniRouteEngine(_OpenAICompatibleEngine):
    """OpenAI-compatible engine for an OmniRoute gateway."""

    engine_id = "omniroute"
    _default_host = "http://localhost:20128"
    _api_prefix = "/v1"

    def __init__(
        self,
        host: str | None = None,
        *,
        api_key: str | None = None,
        timeout: float = 600.0,
        retries: int | None = None,
    ) -> None:
        resolved = host or os.environ.get("OMNIROUTE_HOST") or self._default_host
        # ``_api_prefix`` re-adds /v1, so accept both ``https://h`` and
        # ``https://h/v1`` in OMNIROUTE_HOST.
        super().__init__(
            normalize_openai_base_url(resolved), api_key=api_key, timeout=timeout
        )
        n = _env_retries() if retries is None else max(0, retries)
        if n:
            self._client.close()
            self._client = httpx.Client(
                base_url=self._host,
                timeout=timeout,
                headers=self._headers,
                transport=_RetryTransport(httpx.HTTPTransport(), n),
            )
            self._async_transport = _AsyncRetryTransport(
                httpx.AsyncHTTPTransport(), n
            )


__all__ = ["OmniRouteEngine"]
